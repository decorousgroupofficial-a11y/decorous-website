import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  Phone,
  MessageCircle,
  CheckCircle,
  Home,
  Building2,
  Palette,
  Warehouse,
  Factory,
  Users,
  Award,
  Clock,
  Shield,
  MapPin,
  IndianRupee,
  ClipboardCheck,
  Ruler,
  Star,
  FileText,
  Camera,
  Layers,
  Sparkles,
  Hammer,
  BadgeCheck,
  CalendarCheck,
  SearchCheck,
  Building,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import LeadForm from '@/components/forms/LeadForm';
import Seo from '@/components/Seo';
import { getJson } from '@/lib/api';
import { services as fallbackServices, projects as fallbackProjects, testimonials as fallbackTestimonials, stats as fallbackStats } from '@/data/siteData';

const serviceIcons = {
  Home,
  Building2,
  Palette,
  Warehouse,
  Factory,
};

const HomePage = () => {
  const [services, setServices] = useState(fallbackServices);
  const [projects, setProjects] = useState(fallbackProjects.filter((project) => project.featured));
  const [testimonials, setTestimonials] = useState(fallbackTestimonials);
  const [stats, setStats] = useState(fallbackStats);
  const whatsappNumber = '917008863329';
  const heroImage = 'https://images.unsplash.com/photo-1769780510442-60d4d6391a91?q=85&w=1600&auto=format&fit=crop';

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const [serviceData, projectData, testimonialData, statsData] = await Promise.all([
      getJson('/services', fallbackServices),
      getJson('/projects?featured=true', fallbackProjects.filter((project) => project.featured)),
      getJson('/testimonials', fallbackTestimonials),
      getJson('/stats', fallbackStats),
    ]);
    setServices(serviceData);
    setProjects(projectData);
    setTestimonials(testimonialData);
    setStats(statsData);
  };

  const trustIndicators = [
    { icon: Shield, text: 'BOQ-first pricing' },
    { icon: Award, text: 'Engineer-led execution' },
    { icon: CheckCircle, text: 'Material transparency' },
    { icon: Clock, text: 'Milestone reporting' },
    { icon: Users, text: 'Single accountable team' },
  ];

  const decisionProof = [
    {
      icon: FileText,
      title: 'Written scope before execution',
      description: 'Every serious project starts with a clear BOQ, execution scope and milestone plan so you are not dependent on verbal promises.',
    },
    {
      icon: Camera,
      title: 'Progress visibility on site',
      description: 'Daily photo-led updates, DPR discipline and milestone reviews help owners monitor quality even when they cannot visit every day.',
    },
    {
      icon: Layers,
      title: 'Civil + interiors coordination',
      description: 'Structure, MEP, finishing and interiors are planned together, reducing rework between contractors and protecting final finish quality.',
    },
    {
      icon: BadgeCheck,
      title: 'Premium finish mindset',
      description: 'We plan for durability, maintenance, comfort and long-term value — not just short-term lowest-cost execution.',
    },
  ];

  const clientObjections = [
    { concern: 'Will the final cost keep increasing?', response: 'We define scope, BOQ and assumptions before execution so changes are controlled and documented.' },
    { concern: 'How do I know material quality?', response: 'Material brands, grades and quantities are made visible through BOQ and milestone checks.' },
    { concern: 'What if I cannot visit site daily?', response: 'Progress updates, photos and milestone reporting keep you informed from anywhere.' },
    { concern: 'Who is responsible if something goes wrong?', response: 'You deal with one accountable Decorous team instead of managing multiple independent vendors.' },
  ];

  const projectPlaybook = [
    { step: '01', icon: SearchCheck, title: 'Site & requirement diagnosis', description: 'We study the plot, budget, usage, timeline and quality expectations before suggesting any solution.' },
    { step: '02', icon: Ruler, title: 'Design, BOQ & milestone plan', description: 'Architecture, structure, MEP, interiors and budget are aligned into a clear execution roadmap.' },
    { step: '03', icon: Hammer, title: 'Controlled execution', description: 'Work is executed through site planning, material tracking, supervision and quality checkpoints.' },
    { step: '04', icon: CalendarCheck, title: 'Handover with documentation', description: 'Final inspection, snag closure and handover documents help protect long-term ownership.' },
  ];

  const costBands = [
    { title: 'Standard Home Construction', range: '₹1,650–₹2,400 / sq ft', note: 'RCC structure, MEP and standard finishing. Final cost depends on drawings, soil, materials and finish choices.' },
    { title: 'Premium Home Construction', range: '₹2,400–₹3,500 / sq ft', note: 'Higher-grade finishes, refined detailing, modular coordination and premium material choices.' },
    { title: 'PEB / Warehouse', range: '₹950–₹1,400 / sq ft', note: 'Varies by span, height, cladding, flooring, loading requirements and industrial utility needs.' },
  ];

  const serviceAreas = ['Bhubaneswar', 'Cuttack', 'Puri', 'Khordha', 'Berhampur', 'Rourkela', 'Sambalpur'];

  const homeFaqs = [
    { question: 'What makes Decorous different from a normal contractor?', answer: 'Decorous works as an engineer-led construction partner with BOQ-based pricing, planned milestones, material transparency and single-point accountability from design to handover.' },
    { question: 'Can Decorous handle both construction and interiors?', answer: 'Yes. Decorous can execute civil construction, MEP, finishing, modular kitchen, wardrobes, office interiors and commercial fit-outs as one coordinated scope.' },
    { question: 'Do you provide a free estimate before starting?', answer: 'Yes. You can request a free consultation and initial cost estimate. A detailed BOQ and final scope are prepared after understanding the site and requirements.' },
    { question: 'Which cities do you serve?', answer: 'Decorous serves Bhubaneswar, Cuttack, Puri, Khordha, Berhampur, Rourkela, Sambalpur and other major locations across Odisha depending on project scope.' },
  ];

  const homeJsonLd = [
    {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: homeFaqs.map((item) => ({
        '@type': 'Question',
        name: item.question,
        acceptedAnswer: { '@type': 'Answer', text: item.answer },
      })),
    },
    {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: 'https://decorous.in/' },
      ],
    },
    {
      '@context': 'https://schema.org',
      '@type': 'Service',
      name: 'Turnkey Construction and Interior Execution in Odisha',
      provider: { '@id': 'https://decorous.in/#business' },
      areaServed: serviceAreas.map((city) => ({ '@type': 'City', name: city })),
      serviceType: ['Residential Construction', 'Commercial Construction', 'Interior Design', 'PEB Warehouse Construction'],
    },
  ];

  return (
    <div className="pb-16 md:pb-0">
      <Seo
        path="/"
        title="Decorous | Premium Construction Company in Bhubaneswar, Odisha"
        description="Engineer-led home construction, commercial construction, interiors and PEB warehouse projects in Odisha. BOQ-first pricing, site visibility and premium execution."
        jsonLd={homeJsonLd}
      />

      {/* Hero Section */}
      <section className="relative min-h-[92vh] flex items-center overflow-hidden" data-testid="hero-section">
        <div className="absolute inset-0 overflow-hidden" aria-hidden="true">
          <img
            src={heroImage}
            alt="Premium building construction site managed by Decorous in Bhubaneswar Odisha"
            className="h-full w-full object-cover"
            fetchPriority="high"
            decoding="async"
          />
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(245,166,35,0.22),transparent_30%),linear-gradient(135deg,rgba(10,28,52,0.96),rgba(26,54,93,0.88)_45%,rgba(15,36,66,0.98))]" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 md:px-8 py-20 grid lg:grid-cols-[1.05fr_0.95fr] gap-12 items-center">
          <div className="text-white">
            <div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm font-semibold text-[#F5A623] backdrop-blur">
              <Sparkles size={16} /> Engineer-led construction partner for Odisha
            </div>
            <h1 className="mt-6 text-4xl md:text-5xl lg:text-7xl font-bold mb-6 leading-[1.02] text-white tracking-tight">
              Build with clarity. Execute with confidence.
            </h1>
            <p className="text-lg md:text-xl text-white/82 mb-8 leading-relaxed max-w-2xl">
              Decorous delivers premium homes, commercial spaces, interiors and PEB buildings with BOQ-first pricing, site visibility and single-point accountability.
            </p>
            <div className="grid sm:grid-cols-3 gap-3 mb-8 max-w-2xl">
              <div className="rounded-2xl border border-white/15 bg-white/10 p-4 backdrop-blur">
                <p className="text-2xl font-bold text-[#F5A623]">BOQ</p>
                <p className="text-sm text-white/75">Before commitment</p>
              </div>
              <div className="rounded-2xl border border-white/15 bg-white/10 p-4 backdrop-blur">
                <p className="text-2xl font-bold text-[#F5A623]">DPR</p>
                <p className="text-sm text-white/75">Progress visibility</p>
              </div>
              <div className="rounded-2xl border border-white/15 bg-white/10 p-4 backdrop-blur">
                <p className="text-2xl font-bold text-[#F5A623]">1 Team</p>
                <p className="text-sm text-white/75">Design to handover</p>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/contact">
                <Button className="bg-[#F5A623] text-black hover:bg-[#e09612] h-14 px-8 text-lg font-semibold rounded-xl" data-testid="hero-consultation-btn">
                  Book Free Consultation
                  <ArrowRight className="ml-2" size={20} />
                </Button>
              </Link>
              <Link to="/projects">
                <Button variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-[#1a365d] h-14 px-8 text-lg rounded-xl" data-testid="hero-projects-btn">
                  View Our Work
                </Button>
              </Link>
            </div>
            <div className="flex flex-wrap gap-4 mt-8">
              <a href="tel:7008863329" className="flex items-center gap-2 text-white/80 hover:text-[#F5A623] transition-colors" data-testid="hero-call-link">
                <Phone size={20} /> <span>Call 7008863329</span>
              </a>
              <a href={`https://wa.me/${whatsappNumber}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-white/80 hover:text-[#25D366] transition-colors" data-testid="hero-whatsapp-link">
                <MessageCircle size={20} /> <span>WhatsApp Project Details</span>
              </a>
            </div>
          </div>

          <div className="hidden lg:block">
            <div className="rounded-[2rem] border border-white/20 bg-white/95 p-3 shadow-2xl backdrop-blur">
              <LeadForm
                source="homepage_hero"
                variant="hero"
                title="Get a BOQ-led construction estimate"
                showPlotSize={true}
                showConstructionType={true}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mobile Lead Form */}
      <section className="lg:hidden py-12 px-4 bg-slate-50">
        <LeadForm source="homepage_mobile" title="Get Free Construction Cost Estimate" showPlotSize={true} showConstructionType={true} />
      </section>

      {/* Trust Bar */}
      <section className="py-12 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex flex-wrap justify-center gap-6 md:gap-12">
            {trustIndicators.map((item) => (
              <div key={item.text} className="flex items-center gap-2 text-slate-700">
                <item.icon size={20} className="text-[#F5A623]" />
                <span className="font-medium">{item.text}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Client Decision Section */}
      <section className="py-20 bg-slate-50" data-testid="decision-proof-section">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-10 items-start">
            <div className="lg:sticky lg:top-28">
              <p className="text-[#F5A623] font-semibold mb-2 uppercase tracking-wider text-sm">Built for serious project owners</p>
              <h2 className="text-3xl md:text-5xl font-bold text-[#1a365d] mb-5 leading-tight">A construction experience designed to reduce uncertainty</h2>
              <p className="text-slate-600 leading-relaxed text-lg">
                Most construction stress comes from unclear scope, poor communication and fragmented responsibility. Decorous solves that with documentation, visibility and accountable execution.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row gap-3">
                <Link to="/process">
                  <Button className="bg-[#1a365d] text-white hover:bg-[#0f2442] rounded-xl">See Our Process</Button>
                </Link>
                <a href={`https://wa.me/${whatsappNumber}`} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" className="border-[#1a365d] text-[#1a365d] hover:bg-[#1a365d] hover:text-white rounded-xl">Discuss on WhatsApp</Button>
                </a>
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              {decisionProof.map((item) => (
                <div key={item.title} className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:-translate-y-1 hover:shadow-lg transition-all">
                  <div className="w-12 h-12 rounded-2xl bg-[#1a365d] text-white flex items-center justify-center mb-4">
                    <item.icon size={22} />
                  </div>
                  <h3 className="text-lg font-bold text-[#1a365d] mb-2">{item.title}</h3>
                  <p className="text-sm text-slate-600 leading-relaxed">{item.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Objection Handling */}
      <section className="py-20 bg-white" data-testid="objection-section">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="text-center mb-12">
            <p className="text-[#F5A623] font-semibold mb-2 uppercase tracking-wider text-sm">Trust before transaction</p>
            <h2 className="text-3xl md:text-4xl font-bold text-[#1a365d]">The questions every smart client asks before hiring a builder</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-5">
            {clientObjections.map((item) => (
              <div key={item.concern} className="rounded-3xl border border-slate-200 bg-slate-50 p-6">
                <p className="font-bold text-[#1a365d] mb-3">{item.concern}</p>
                <p className="text-slate-600 leading-relaxed">{item.response}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-[#1a365d]" data-testid="stats-section">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center"><p className="text-4xl md:text-5xl font-bold text-[#F5A623]">{stats.projects_completed || 500}+</p><p className="text-white/80 mt-2">Projects Completed</p></div>
            <div className="text-center"><p className="text-4xl md:text-5xl font-bold text-[#F5A623]">{stats.engineers || 10}+</p><p className="text-white/80 mt-2">Expert Engineers</p></div>
            <div className="text-center"><p className="text-4xl md:text-5xl font-bold text-[#F5A623]">{stats.client_satisfaction || 100}%</p><p className="text-white/80 mt-2">Client Satisfaction</p></div>
            <div className="text-center"><p className="text-4xl md:text-5xl font-bold text-[#F5A623]">{stats.years_experience || 8}+</p><p className="text-white/80 mt-2">Years Experience</p></div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-20 bg-white" data-testid="services-section">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
            <div>
              <p className="text-[#F5A623] font-semibold mb-2 uppercase tracking-wider text-sm">Our Services</p>
              <h2 className="text-3xl md:text-5xl font-bold text-[#1a365d]">Complete construction solutions</h2>
              <p className="text-slate-600 mt-4 max-w-2xl">Residential, commercial, interiors and industrial execution under one professional operating system.</p>
            </div>
            <Link to="/services">
              <Button variant="outline" className="border-[#1a365d] text-[#1a365d] hover:bg-[#1a365d] hover:text-white rounded-xl">Explore Services</Button>
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service) => {
              const IconComponent = serviceIcons[service.icon] || Home;
              return (
                <Link key={service.id} to={`/services/${service.slug}`} className="group" data-testid={`service-card-${service.slug}`}>
                  <article className="bg-white border border-slate-200 rounded-3xl overflow-hidden hover:shadow-xl transition-all duration-300">
                    <div className="aspect-video overflow-hidden bg-slate-100">
                      <img src={service.image} alt={`${service.name} by Decorous in Odisha`} loading="lazy" decoding="async" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    </div>
                    <div className="p-6">
                      <div className="w-12 h-12 bg-[#1a365d] text-white rounded-2xl flex items-center justify-center mb-4 group-hover:bg-[#F5A623] group-hover:text-black transition-colors">
                        <IconComponent size={24} />
                      </div>
                      <h3 className="text-xl font-bold text-[#1a365d] mb-2">{service.name}</h3>
                      <p className="text-slate-600 mb-4 line-clamp-2">{service.short_description}</p>
                      <span className="text-[#F5A623] font-semibold flex items-center gap-2 group-hover:gap-3 transition-all">View Service <ArrowRight size={16} /></span>
                    </div>
                  </article>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Project Playbook */}
      <section className="py-20 bg-slate-50" data-testid="playbook-section">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="text-center mb-12">
            <p className="text-[#F5A623] font-semibold mb-2 uppercase tracking-wider text-sm">Execution playbook</p>
            <h2 className="text-3xl md:text-5xl font-bold text-[#1a365d]">How we turn an idea into a controlled project</h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
            {projectPlaybook.map((step) => (
              <div key={step.step} className="relative rounded-3xl bg-white p-6 border border-slate-200 shadow-sm">
                <p className="text-sm font-bold text-[#F5A623] mb-5">{step.step}</p>
                <div className="w-12 h-12 rounded-2xl bg-[#1a365d] text-white flex items-center justify-center mb-5"><step.icon size={22} /></div>
                <h3 className="text-xl font-bold text-[#1a365d] mb-3">{step.title}</h3>
                <p className="text-slate-600 text-sm leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio */}
      <section className="py-20 bg-white" data-testid="portfolio-section">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="text-center mb-12">
            <p className="text-[#F5A623] font-semibold mb-2 uppercase tracking-wider text-sm">Proof of work</p>
            <h2 className="text-3xl md:text-5xl font-bold text-[#1a365d]">Featured projects</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.slice(0, 6).map((project) => (
              <article key={project.id} className="group rounded-3xl overflow-hidden border border-slate-200 bg-white shadow-sm" data-testid={`project-card-${project.id}`}>
                <div className="aspect-[4/3] overflow-hidden bg-slate-100">
                  <img src={project.images[0]} alt={`${project.title} completed by Decorous in ${project.location}`} loading="lazy" decoding="async" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-6">
                  <span className="text-[#F5A623] text-sm font-bold uppercase tracking-wider">{project.category}</span>
                  <h3 className="text-[#1a365d] text-xl font-bold mt-2">{project.title}</h3>
                  <p className="text-slate-600 text-sm mt-2">{project.location} · {project.area_sqft} sqft</p>
                  <p className="text-slate-500 text-sm mt-4">A Decorous execution case study focused on planning, quality control and practical handover value.</p>
                </div>
              </article>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link to="/projects">
              <Button className="bg-[#F5A623] text-black hover:bg-[#e09612] rounded-xl" data-testid="view-all-projects">View All Projects <ArrowRight className="ml-2" size={16} /></Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Cost Transparency */}
      <section className="py-20 bg-slate-50" data-testid="cost-transparency-section">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-10 items-center">
            <div>
              <p className="text-[#F5A623] font-semibold mb-2 uppercase tracking-wider text-sm">Budget clarity</p>
              <h2 className="text-3xl md:text-5xl font-bold text-[#1a365d] mb-4">Indicative construction cost in Odisha</h2>
              <p className="text-slate-600 text-lg leading-relaxed">These are planning ranges. The final quote depends on soil, design, structure, materials, MEP, finishes and site conditions. Decorous gives a detailed BOQ before execution.</p>
              <Link to="/cost-calculator" className="inline-block mt-8">
                <Button className="bg-[#F5A623] text-black hover:bg-[#e09612] rounded-xl">Check Your Approximate Budget</Button>
              </Link>
            </div>
            <div className="grid gap-4">
              {costBands.map((band) => (
                <div key={band.title} className="rounded-3xl border border-slate-200 p-6 bg-white hover:border-[#F5A623] transition-colors">
                  <h3 className="text-xl font-bold text-[#1a365d] mb-2">{band.title}</h3>
                  <p className="text-2xl font-bold text-[#F5A623] mb-2">{band.range}</p>
                  <p className="text-sm text-slate-600 leading-relaxed">{band.note}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Service Area */}
      <section className="py-16 bg-white" data-testid="service-area-section">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="grid lg:grid-cols-[0.8fr_1.2fr] gap-10 items-center">
            <div>
              <p className="text-[#F5A623] font-semibold mb-2 uppercase tracking-wider text-sm">Local Odisha presence</p>
              <h2 className="text-3xl md:text-4xl font-bold text-[#1a365d] mb-4">Construction and interiors across key Odisha cities</h2>
              <p className="text-slate-600">Our strongest operating base is Bhubaneswar, with service coverage expanding across Odisha for qualified residential, commercial, interior and industrial projects.</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {serviceAreas.map((city) => (
                <Link key={city} to="/cities" className="flex items-center gap-2 rounded-2xl bg-slate-50 border border-slate-200 p-4 hover:border-[#F5A623] hover:shadow-sm transition-all">
                  <MapPin size={18} className="text-[#F5A623]" />
                  <span className="font-semibold text-[#1a365d]">{city}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-slate-50" data-testid="testimonials-section">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="text-center mb-12">
            <p className="text-[#F5A623] font-semibold mb-2 uppercase tracking-wider text-sm">Client voice</p>
            <h2 className="text-3xl md:text-5xl font-bold text-[#1a365d]">What clients value about Decorous</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.slice(0, 3).map((testimonial) => (
              <article key={testimonial.id} className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 relative" data-testid={`testimonial-${testimonial.id}`}>
                <div className="text-5xl text-[#F5A623] opacity-30 absolute top-4 left-6">&quot;</div>
                <p className="text-slate-600 mb-6 relative z-10 pt-6">{testimonial.content}</p>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-[#1a365d] rounded-full flex items-center justify-center text-white font-bold">{testimonial.name.charAt(0)}</div>
                  <div><p className="font-semibold text-[#1a365d]">{testimonial.name}</p><p className="text-sm text-slate-500">{testimonial.project_type} · {testimonial.location}</p></div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 bg-white" data-testid="homepage-faq-section">
        <div className="max-w-4xl mx-auto px-4 md:px-8">
          <div className="text-center mb-10">
            <p className="text-[#F5A623] font-semibold mb-2 uppercase tracking-wider text-sm">Quick answers</p>
            <h2 className="text-3xl md:text-4xl font-bold text-[#1a365d]">Questions before starting your project</h2>
          </div>
          <div className="divide-y divide-slate-200 rounded-3xl border border-slate-200 bg-white overflow-hidden">
            {homeFaqs.map((item) => (
              <div key={item.question} className="p-6">
                <h3 className="text-lg font-bold text-[#1a365d] mb-2">{item.question}</h3>
                <p className="text-slate-600 leading-relaxed">{item.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-[#1a365d]" data-testid="cta-section">
        <div className="max-w-4xl mx-auto px-4 md:px-8 text-center">
          <p className="text-[#F5A623] font-semibold mb-3 uppercase tracking-wider text-sm">Start with clarity</p>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">Planning a home, office or commercial project in Odisha?</h2>
          <p className="text-white/80 text-lg mb-8">Get a free consultation and initial estimate from the Decorous team. No obligation — just clear guidance.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/contact">
              <Button className="bg-[#F5A623] text-black hover:bg-[#e09612] h-14 px-8 text-lg font-semibold rounded-xl" data-testid="cta-start-project">Start Your Project <ArrowRight className="ml-2" size={20} /></Button>
            </Link>
            <a href={`https://wa.me/${whatsappNumber}`} target="_blank" rel="noopener noreferrer">
              <Button variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-[#1a365d] h-14 px-8 text-lg rounded-xl" data-testid="cta-whatsapp">WhatsApp Now</Button>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
