# Decorous V3 Phase 2 — Website Growth Implementation

## Release goal
Improve the public marketing website first, while leaving Admin/ERP authentication for a later dedicated backend/authentication milestone.

## What changed
- Strengthened the homepage positioning from a generic construction site into a premium construction partner message.
- Added a new conversion proof section explaining BOQ-first pricing, daily site visibility, design + execution coordination, and premium finish mindset.
- Added a budget clarity section with indicative Odisha construction cost bands.
- Added a service-area cluster for Bhubaneswar, Cuttack, Puri, Khordha, Berhampur, Rourkela and Sambalpur.
- Added homepage FAQ content and FAQPage JSON-LD for better search visibility.
- Added BreadcrumbList JSON-LD for the homepage.
- Preserved existing website design language, colors, routing, forms, Admin and ERP pages.

## Verified
- `CI=true npm run build` completed successfully.
- Static sitemap XML parses successfully.
- Existing route-level code splitting remains active.

## Not included in this phase
- Admin login repair.
- ERP login repair.
- Database authentication migration.

These are intentionally deferred so the public website can continue improving without destabilizing internal applications.
