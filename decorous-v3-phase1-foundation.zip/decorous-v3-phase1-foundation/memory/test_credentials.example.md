# Test credentials example

Do not commit real production passwords here.

## Marketing admin
- URL: `/admin`
- Username: `admin`
- Password: set privately in backend environment variable `ADMIN_PASSWORD`

## ERP
- URL: `/erp/login`
- Create users through `/erp/signup` or seeded backend data in a private environment.
- Store `ERP_JWT_SECRET`, `MONGO_URL`, and `DB_NAME` only in your backend hosting provider's environment variables.
