# Decorous V3 CTO Foundation Release

This package is the V3 Phase-1 foundation release. It keeps the approved public design while hardening routing, sitemap, subdomains, performance and deployment safety.

# Decorous Digital Platform v2.0

Production-ready Decorous website package prepared for GitHub + Vercel deployment.

Main deployable frontend lives in `frontend/`.
Backend/ERP source is preserved for future API/database deployment.

Read `docs/CTO_FINAL_RELEASE_REPORT.md` before production deployment.
