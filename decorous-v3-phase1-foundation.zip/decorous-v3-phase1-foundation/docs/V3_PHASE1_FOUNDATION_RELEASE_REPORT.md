# Decorous V3 — Phase 1 Foundation Release Report

## Release goal
This release is not a redesign. It is the CTO-grade technical foundation for the current Decorous website, preserving the approved visual design while fixing deployment, SEO, routing, performance and maintainability risks.

## Verified changes

### 1. Public website stability
- `decorous.in` remains the SEO marketing website.
- Static fallback content stays available even if the backend API is offline.
- Lead forms use backend API when configured and fall back to WhatsApp if unavailable.

### 2. Sitemap and robots
- `frontend/public/sitemap.xml` is static, valid XML and contains 47 canonical `https://decorous.in` URLs.
- `/api/sitemap.xml` redirects to `/sitemap.xml`.
- `robots.txt` points to `https://decorous.in/sitemap.xml`.
- Admin and ERP routes are blocked from search crawling.

### 3. Subdomain provision
- `admin.decorous.in` is routed to `/admin`.
- `app.decorous.in` is routed to `/erp`.
- `api.decorous.in` is reserved as the future backend API origin.
- Redirect-loop risk from the earlier host redirect approach has been removed.

### 4. Performance
- React route-level code splitting is enabled.
- Hero image is now a real high-priority image instead of only a CSS background image.
- Hero image and image CDN are preloaded/preconnected.
- Verified frontend build success with `CI=true npm run build`.

### 5. Security and production hygiene
- Stronger Vercel security headers are included.
- Admin and ERP routes emit noindex headers.
- No `.env`, `node_modules`, build cache or real credentials are included.
- Emergent runtime scripts/badges/customer asset references/PostHog builder tracking are absent from production source.

## Build verification
- Command: `CI=true npm run build`
- Result: compiled successfully.
- Main JS gzip: ~119.87 KB.
- Sitemap XML parse: passed.

## What remains for V3 Phase 2
- Deploy `api.decorous.in` backend independently.
- Build true Admin CMS for blogs, projects, services, testimonials and SEO metadata.
- Expand programmatic local SEO pages.
- Separate ERP into a first-class app surface with production auth, permissions and audit logging.
