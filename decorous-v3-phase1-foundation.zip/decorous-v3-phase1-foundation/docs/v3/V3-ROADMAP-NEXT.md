# Decorous V3 — Next Build Roadmap

## Phase 2: True CMS + API

Build `api.decorous.in` and `admin.decorous.in` as first-class products.

Required modules:
- Leads
- Blog manager
- Service pages
- City pages
- Projects/case studies
- Testimonials
- Gallery
- SEO metadata manager
- Users and roles

## Phase 3: SEO Scale Engine

Add programmatic page creation for:
- Construction by city
- Interior design by city
- Commercial construction by city
- PEB/warehouse by industry
- Cost calculators by city and service

## Phase 4: ERP Separation

Move active ERP to `app.decorous.in` with isolated backend auth, role permissions, audit logs and approval workflows.

## Phase 5: AI Business Tools

Add:
- BOQ generator
- Cost estimator
- Tender analyzer
- Drawing reader
- Client update generator

