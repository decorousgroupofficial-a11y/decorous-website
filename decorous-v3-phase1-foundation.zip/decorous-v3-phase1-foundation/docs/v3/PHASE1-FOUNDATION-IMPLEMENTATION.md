# Decorous V3 — Phase 1 Foundation Implementation

This release hardens the existing production codebase without changing the approved Decorous visual design.

## What changed

1. **Subdomain routing fixed**
   - `decorous.in` remains the public SEO website.
   - `admin.decorous.in` rewrites to the internal admin console.
   - `app.decorous.in` rewrites to the ERP surface.
   - Redirect-loop risk from host-based redirects was removed.

2. **Sitemap is permanent and static**
   - `frontend/public/sitemap.xml` is served directly by Vercel.
   - `/api/sitemap.xml` redirects to `/sitemap.xml`.
   - No sitemap request depends on Emergent or any backend.

3. **API dependency isolated**
   - Public marketing pages use static fallback content.
   - Lead forms fall back to WhatsApp if API is unavailable.
   - Future backend should live at `api.decorous.in`.

4. **Performance improvements**
   - Route-level React code splitting remains enabled.
   - Hero image now uses an actual high-priority `<img>` rather than CSS-only background image.
   - `images.unsplash.com` is preconnected and hero image is preloaded.

5. **Security posture improved**
   - Stronger Vercel security headers.
   - Admin and ERP routes remain `noindex`.
   - `.env` files and credentials are excluded from the release.

## Deployment rule

Deploy to a Vercel preview first. Promote to production only after checking:

- `/`
- `/sitemap.xml`
- `/robots.txt`
- `/admin`
- `/erp`
- Lead form fallback to WhatsApp

