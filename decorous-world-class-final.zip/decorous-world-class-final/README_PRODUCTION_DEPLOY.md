# Decorous Production Deployment

This package is prepared for a clean production deployment.

## Frontend
Deploy the `frontend/` folder to Vercel.
Root Directory: `frontend`
Framework: Create React App
Build Command: `npm run build`
Output Directory: `build`

Attach these domains to the same Vercel project:
- decorous.in
- www.decorous.in
- admin.decorous.in
- app.decorous.in

## Backend
Deploy the `backend/` folder to your backend host and point `api.decorous.in` to it.
Set the variables from `backend/.env.example`.

## Final checks after deployment
- https://decorous.in
- https://decorous.in/sitemap.xml
- https://decorous.in/robots.txt
- https://admin.decorous.in
- https://app.decorous.in
- https://api.decorous.in/api/
