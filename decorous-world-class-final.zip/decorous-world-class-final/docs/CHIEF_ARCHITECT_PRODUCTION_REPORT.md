# Decorous World-Class Production Overhaul

Generated for Decorous as a production-ready handoff.

## What changed

1. `frontend/public/sitemap.xml` is now static and canonical, with 47 URLs on `https://decorous.in`.
2. `frontend/vercel.json` no longer proxies the sitemap to Emergent. `/api/sitemap.xml` redirects to `/sitemap.xml`.
3. `frontend/vercel.json` now provisions:
   - `decorous.in` for marketing pages
   - `admin.decorous.in` root redirect to `/admin`
   - `app.decorous.in` root redirect to `/erp/login`
   - `/api/*` proxy to `https://api.decorous.in/api/*`
4. `robots.txt` blocks `/admin` and `/erp`, while pointing Google to the canonical sitemap.
5. React routes are code-split with `React.lazy` and `Suspense`.
6. Emergent builder scripts, badge, PostHog builder tracking, and visual edit package were removed.
7. Real `.env` files were removed and replaced with safe `.env.example` files.
8. Security headers were added in Vercel.
9. Backend CORS was restricted to production domains instead of `*` with credentials.
10. The parked `/erp` reference monorepo was removed from this production package to avoid confusion.

## Required production domains

- `decorous.in` → Vercel marketing/frontend project
- `www.decorous.in` → redirect/alias to `decorous.in`
- `admin.decorous.in` → same Vercel project
- `app.decorous.in` → same Vercel project
- `api.decorous.in` → FastAPI backend host

## Vercel environment

Frontend can work without `REACT_APP_BACKEND_URL` if `/api/*` is proxied to `api.decorous.in` by Vercel.
For local development only, set `REACT_APP_BACKEND_URL`.

## Backend environment

Use `backend/.env.example` and never commit the real `.env` file.
